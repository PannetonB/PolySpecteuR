 #************************************************************************************
  #************************************************************************************
  #---------------------------------E N T Ê T E----------------------------------------
  #
  nomInstrument="HS1"
  #///////////////////////////////////////////////////////////////////////////////////
  # F I C H I E R S    D E    C O R R E C T I O N (Étalonnage en Y)
  QEPro_Calib_File="Calib_Data/Calib_QE_pour_Raman_jan2018.txt"
  
  #///////////////////////////////////////////////////////////////////////////////////    
  # S P E C T R O S   ET  M O D U L E USB pour laser
  les_spectro=list()
  les_mcusb=list()
  les_spectro$name="USB4000"
  les_spectro$serial="USB4F06255"
  les_mcusb$name="USB-3104"
  les_mcusb$serial="111036"
  sourceLaser = "LS2"
  
 
















