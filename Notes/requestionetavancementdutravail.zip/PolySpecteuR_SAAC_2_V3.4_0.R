PolySpecteuR_SAAC_2<-function(){
  #************************************************************************************
  # Cr�� � partir de PolySpecteuR_Fluo_SpectrAAC_2 V4 pour inclure des mesures de r�flectance.
  # Voir modifications de Avril 2018.
  #************************************************************************************
  # - Programme g�rant l'acquisition de donn�es avec le SpectrAAC 2
  # - Les acquisitions sont faites en s�quence. 
  # - Les param�tres d'acquisition sont d�finies dans un fichier de configuration
  # - Le programme va r�p�ter le cycle d'acquisition tant
  #   que l'op�rateur n'indiquera pas que c'est termin�.
  # - Les fichiers de donn�es sont stock�s dans un r�pertoire au choix de l'utilisateur.
  #   Le nom des fichiers est normalis�: type de donn�es + date
  #   Les fichierssont des fichiers en format texte et les colonnes s�par�es par un tab.
  #   Toutes les donn�es sont stock�es en brut (i.e. tel que r�cup�r�es des spectros)
  #   et apr�s interpolation. Le nom des fichiers de donn�es bruts se termine par un B
  #   et celui des donn�es interpol�es par upolyn I.
  # - Les donn�es du spectro Maya sont corrig�es � l'aide de donn�es
  #   stock�es dans un fichier texte que l'op�rateur doit sp�cifier dans le fichier de
  #   configuration.
  # 
  #************************************************************************************
  # AUTEUR: Bernard Panneton, Agriculture et Agroalimentaire Canada
  # 16 novembre 2017
  #************************************************************************************
  # MODIFICATIONS - 31 janvier 2018
  # - Utilise un fichier de configuration pour les instruments. Ce fichier nomm�
  #   ????_Config.R, contient l'identification du spectro (nom et no de s�rie), 
  #   l'identification du module de MC (nom et no de s�rie) et la d�finition
  #   des ports pour les modules MC. Ainsi, l'utilisateur choisit un instrument
  #   dans une liste �tablie � partir du contenu du r�pertoire "Fichiers_Instruments"
  #   et le programme se charge de tout lancer du c�t� du hardware.
  #************************************************************************************
  # MODIFICATIONS - 7 f�vrier 2018
  # - Modifi� pour pouvoir travailler sur 2 instruments dans une m�me session. Pour les 2 instruments,
  #   on utilise le m�me fichier de param�tres d'acquisition.
  # - Modifi� pour pouvoir prendre des mesures r�p�t�es sur le m�me �chantillon (pour la position).
  #   Le nombre de r�p�titions est sp�cifi� par un param�tre dans le fichier des param�tres
  #   d'acquisition.
  #************************************************************************************
  # MODIFICATIONS - Mars 2018 - V4
  #   Inclure une v�rification de l'instrument au d�marrage.
  #   VOir la section V�rification de l'�tat d'instrument plus bas.
  #************************************************************************************
  #************************************************************************************
  # MODIFICATIONS - Avril 2018 - PolySpecteuR_Fluo_n_Reflect_SpectrAAC_2 V1
  #   Le programme PolySepcteur_Fluo_SpectrAAC_2 a �t� modifi� suite � la modification 
  #   de l'instrument pour permettre des mesures de r�flectance. On maintient la
  #   fonctionalit� de pouvoir travailler avec 2 instruments.
  #   La strat�gie retenue est de placer l'�chantillon et de faire les mesures
  #   de fluorescence et de r�flectance pour cet �chantillon.
  #   Le fichier de configuration de l'appareil contient
  #   les d�finitions de ports et des valeurs de r�f�rence (amp�rages, voltages...)
  #   pour chaque instrument. Le fichier de param�tres contient les param�tres de 
  #   mesure et il est partag� pour les mesures sur les 2 instruments.
  #   La s�quence est la suivante:
  #     - au d�marrage - configuration du mat�riel
  #     - Allumer la lampe blanche pour la r�flectance et fermer l'obturateur.
  #     - Contr�le de qualit� pour la fluorescence.
  #     - Mesures de fluorescence.
  #     - Prise d'un noir qui sera maintenu pour toutes les mesures de r�flectance.
  #     - Ouvre le shutter de la lampe blanche - Mesure sur Spectralon et affiche profil
  #       de la lampe (contr�le de qualit�)
  #     - Ferme shutter
  #     - Ouvre shutter - Mesure blanc - Mesure �chantillon
  #     - Ferme shutter.
  #************************************************************************************
  # Modifications - 31 Janvier 2019
  # Les fichiers de configuration d'instruments comprennent 2 param�tres pour d�finir
  # une fen�tre de recherche pour trouver un maximum de fluorescence dans la sous-routine
  # Mesures_Etalon_Fluo. Ces 2 param�tres vont se retrouver dans les environnements d'instrument.
  #************************************************************************************
  #************************************************************************************
  # Modifications - Juin 2019
  # Modification pour supporter plusieurs instruments dans une meme session de travail.
  # On cr�e un environnement pour chaque instrument qui stocke la configuration et les
  # param�tres de m�me que le spectro correspondant. Les environnements d'instrument sont
  # dans une liste. L'ordre dans cette liste correspond � celui dans d'autres listes/vecteurs:
  # lesspectros, Device, lesinstruments.
  # Nettoyage du code.
  #************************************************************************************
  #************************************************************************************
  # Modifications - Mesures de r�flectance - Aout 2019
  # Modification pour soustraire un estim� du "stray light" estim� par la moyenne 
  # d'intensit� sur une plage de longueur d'onde donn�e dans le fichier de configuration
  # dans la section sur les param�tres pour la r�flectance: stray_low et stray_high 
  # finissent le bas et le haut de la plage utilis�. Si stray_low=0 pas de correction.
  #************************************************************************************
  #************************************************************************************
  # Modifications - Permettre l'utilisation de 8 DELs pour la fluorescence - Sept 2019
  # Permet de travailler avec toutes les DELs d�finies dans le fichier de param�tre. N.B.
  # le fichier de configuration doit comporter les d�finitions n�cessaires pour associer
  # le "hardware" pour le contr�les des DELs.
  #************************************************************************************
  #************************************************************************************
  # Modifications - Permettre l'utilisation de standards de normalisation qui diff�rent
  # selon les DELs pour la fluorescence - Oct 2019
  # N.B. Cela demande des modifications aux fichiers de configuration d'instrument 
  # (temps d'exposition, scans.... et longueur d'onde d'observation) ET aux fichiers
  # de param�tres o� pour chaque position, on a ajout� un param�tre (STD_EXi) identifiant
  # le standard � utiliser pour cette DEL. Dans PolySpecteur_SAAC2, seule la sous-routine
  # "Mesures_Etalon_Fluo" a �t� modifi�e. N.B. Lors de la mise en oeuvre, ce serait 
  # probablement pertinent de cr�er un nouveau fichier "Verif".
  #************************************************************************************
  # Charge des librairies additionnelles
  #-----------------------------------------
  if (!require(rChoiceDialogs)){
    install.packages("rChoiceDialogs", dependencies = T)
    library(rChoiceDialogs)
  }
  if (!require(png)){
    install.packages("png", dependencies = T)
    library(png)
  }
  if (!require(tcltk)){
    install.packages("tcltk", dependencies = T)
    library(tcltk)
  }
  if (!require(tcltk2)){
    install.packages("tcltk2", dependencies = T)
    library(tcltk2)
  }
  if (!require(rpanel)){
    install.packages("rpanel", dependencies = T)
    library(rpanel)
  }
  if (!require(utils)){
    install.packages("utils", dependencies = T)
    library(utils)
  }
  
  if (!require(prospectr)){
    install.packages("prospectr", dependencies = T)
    library(prospectr)
  }
  #-----------------------------------------
 
  # On d�finit le r�pertoire du script en cours
  #-----------------------------------------
  PolySpecteuRPath=getSrcDirectory(function(x) {x})
  setwd( PolySpecteuRPath)
  #-----------------------------------------
  # On charge les librairies pour les modules MC et les spectros.
  #-----------------------------------------
  source('../Lib_n_Wrapper/MCDAQ.R')  
  source('../Lib_n_Wrapper/OOInterface.R')
  #-----------------------------------------
  #************************************************************************************
  
  #___________________________________________________________________________ 
  #------------------- GESTION DE L'INTERFACE USAGER ---------------------------
  #Efface le contenu de la console
  cat("\f")
  #Affiche un message
  cat("Phase d'initialisation des composantes.\n")
  
  logo=readPNG("PolySpecteuR_Logo.png")
  graphics.off()
  op <- par(no.readonly = TRUE)
  #2 graphiques - Logo + spectre de lampe blanche
  nf=layout(matrix(c(1,2),2,1,byrow=TRUE))
  #Affiche le logo
  par(mai=c(0,0,0,0))
  plot(as.raster(logo)) 
  par(mai=op$mai)
  #-----------------------------------------
  
  
  #************************************************************************************
  #------------------ I N I T I A L I S A T I O N S -----------------------------------
  #-------------------------------------------------------------------------
  # On a besoin du spectro, du module DAQ. On
  # va donc commencer par faire les intialisations
  # n�cessaires.
  #____________________________________________________________________________
  # Recherche dans le r�pertoire, les instruments disponibles et propose le choix
  #-----------------------------------------
  lesinstruments=list.files(path='Fichiers_Instruments',pattern = 'Config\\.R$')
  dum=gregexpr(pattern ='_',lesinstruments)
  N_instruments=length(dum)
  instruments=rep("",N_instruments)
  laliste=list()
  for (k in 1:N_instruments){
    n_sep=length(dum[[k]])
    instruments[k]=substr(lesinstruments[k],start=1,stop=dum[[k]][n_sep]-1)
    laliste=c(laliste,instruments[k])
  }
  lesinstruments=select.list(as.character(laliste),multiple=T,title="Choisir les instruments",graphics=T)
  N_instruments=length(lesinstruments)
  #-----------------------------------------
  # Recherche les fichiers de param�tres pour chaque instrument s�lectionn�
  #-----------------------------------------
  fichier_param=character()
  lepath=file.path(getwd(),'Fichiers_Parametres')
  for (k in 1:N_instruments){
    fichier_param[k]=rchoose.files(default=lepath,
                                   caption=paste0("Choisir le fichier des param�tres pour ",
                                                  lesinstruments[k]),
                                   multi = FALSE,filters = "*.R")
    lepath=dirname(fichier_param[k])
  }
  #-----------------------------------------
  # Cr�e des environnements pour chaque instrument s�lectionn� et faire une liste
  #-----------------------------------------
  lesenv <- list()
  for (k in 1:N_instruments){
    lesenv[[k]] <- new.env()
    source(paste("Fichiers_Instruments/",lesinstruments[k],"_Config.R",sep=""),local=lesenv[[k]])
    source(fichier_param[k],local=lesenv[[k]])
  }
  #S'assurer que DoReflect et DoFluo sont partout les m�mes
  partout=TRUE
  for (k in 1:N_instruments){
    tdat <- c(lesenv[[k]]$DoReflect,lesenv[[k]]$DoFluo)
    if (k==1){
      tdat_base <- tdat
    }else
    {
      if (!all(tdat==tdat_base)) partout=F
    }
  }
  if (!partout){
    cat("DoFluo et DoReflect diff�rent dans les fichiers de param�tre.\n")
  }
  
  sameEX <- TRUE
  for (k in 1:N_instruments){
    if (lesenv[[k]]$DoFluo){
      Fluo_EX <- get_DELs_dat("DoEX",mon_envir=lesenv[[k]])
      if (!exists("Fluo_EX_ref")){
        Fluo_EX_ref <- Fluo_EX
      }else
        if (length(Fluo_EX_ref)==length(Fluo_EX)){
          sameEX <- all(Fluo_EX_ref==Fluo_EX)
        }else sameEX <- FALSE
    }
    if (!sameEX) break
  }
  
  if (!sameEX){
    cat("Pas les m�mes DELs entre les instruments pour la fluorescence.\n")
    return("Termin�!")
  }
  
  #-----------------------------------------
  #___________________________________________________________________________
  # Active le "wrapper" donnant acc�s aux spectros.
  #-----------------------------------------
  OOobj=Start_OO()
  if (is.null(OOobj)){
    rm(OOobj)
    return("Termin�.")
  }
  #-----------------------------------------
  #___________________________________________________________________________
  # D�finir les spectros et les plages et intervalles de
  # longueur d'onde pour l'interpolation
  #-----------------------------------------
  # Trouve le spectro de l'instrument.
  lesspectros=list()  #liste des spectros correspondant aux environnements/instruments
  for (k in 1:N_instruments){
    lespectro=which((OOobj$serial_no==lesenv[[k]]$les_spectro$serial) & (OOobj$lesspectros==lesenv[[k]]$les_spectro$name))
    if (length(lespectro)==0){
      cat("Ne trouve pas le spectro!\n Va quitter...\n")
      for (sp in lesspectros) Close_Spectro(sp)
      Quit_OO(OOObj)
      rm(OOobj)
      return("Termin�!")
    }
    #On d�finit le spectro pour l'environnement de l'instrument.
    with(lesenv[[k]],{ 
         lespectro <- Define_Spectro(OOobj,lespectro)
         SetCorrections(OOobj,lespectro,Lin = 1, Dark = 0)
         lespectro <- Define_WavelengthRange(lespectro,fluo_l_min,fluo_l_max,fluo_step)
    })
  }
  #-----------------------------------------
  
  #___________________________________________________________________________
  #On passe au module MC DAQ
 #___________________________________________________________________________
  #-----------------------------------------
  #Initialise les devices
  Init_MCLib()
  lesDevices=GetDevices()
  
  #Initialise chaque board
  for (k in 1:lesDevices$nbdevices)
    dum=Init_DAQ(lesDevices$noms[k],lesDevices$serie[k],lesDevices$BoardNum[k])
  lesnoms=lesDevices$noms[1:lesDevices$nbdevices]
  Device <- list()
  for (k in 1:N_instruments){
    Device[[k]]=which((lesDevices$serie==lesenv[[k]]$les_mcusb$serial) & (lesDevices$noms==lesenv[[k]]$les_mcusb$name))
    if (length(Device[[k]])==0){
      cat("Ne trouve pas le module de MC!\n Va quitter...\n")
      Quitte_MCLIB()
      for (sp in lesspectros) Close_Spectro(sp)
      Quit_OO(OOobj)
      return("Termin�.")
    } 
    #Configure les boards. Seuls les ports DIO sont configur�s.
    Config_Board(lesDevices,lesenv[[k]]$lesPorts)
    #Configure les ports de sortie en courant  et ceux en voltage sur USB-3106
    for (i in lesenv[[k]]$lesports_amp){
      err=.C("BP_cbSetConfig",boardinfo=as.integer(BOARDINFO),bnum=as.integer(lesDevices$BoardNum[Device[[k]]]),
             channelnum=as.integer(i),configitem=as.integer(BIDACRANGE),
             configval=as.integer(MA0TO20),out=as.integer(0))
    }
    for (i in lesenv$lesports_V){
      err=.C("BP_cbSetConfig",boardinfo=as.integer(BOARDINFO),bnum=as.integer(lesDevices$BoardNum[Device[[k]]]),
             channelnum=as.integer(i),configitem=as.integer(BIDACRANGE),
             configval=as.integer(UNI10VOLTS),out=as.integer(0))
    }
    with(lesenv[[k]], gainY<-scan(Maya_Calib_File,sep="\t",quiet=TRUE))
  }
  #-----------------------------------------
  
  
  
  #************************************************************************************
  #V�rification de l'�tat d'instrument - Fluo - Calcul du facteur de normalisation
  #************************************************************************************
  #-----------------------------------------
  #
  cat("\n***************************************\nV�rification de(s) instrument(s)")
  for (k in 1:N_instruments){
      with(lesenv[[k]],{
        lesEXs <- get_DELs_dat("EX",mon_envir=lesenv[[k]])
        if (DoFluo){
          dum <- readline(paste("\nENTER pour mesure le facteur de normalisation pour ", lesinstruments[k],
                         " ou Q-ENTER pour quitter.", sep=""))
          
          if (!(toupper(dum)=="Q")){
            NormY <- Mesures_Etalon_Fluo(lesenv[[k]],lespectro,
                                      OOobj,lesDevices,gainY,logo,op,lesEXs)
            cat(paste("Facteur de correction: ",format(lesenv[[k]]$NormY,
                                                    digits=3,scientific = TRUE),"\n",sep=""))
          }
        }
      })
    if (length(lesenv[[k]]$dum)>0){
      if  (toupper(lesenv[[k]]$dum)=="Q"){
        Abort(lesDevices,lesspectros,OOobj,op)
        graphics.off()
        return("Quitt� pr�matur�ment!")
      }
    }
  }
  
  readline("Appuyer sur Retour/Enter pour continuer. \n")
  #-----------------------------------------
 
  #***********************************************************************************
  # Mise sous tension de la lampe blanche et v�rification du profil
  # On laisse la lampe ouverte mais on ferme le shutter.
  #***********************************************************************************
  #-----------------------------------------
  #G�re la lampe blanche
  # dum <- readline(paste0("V�rifier la lampe blanche pour tous les instruments? ",
  #                        "? (O)ui/(N)on: \n"))
  # if (toupper(dum)=="N"){
  #   Abort(lesDevices,lesspectros,OOobj,op)
  #   graphics.off()
  #   return("Quitt� pr�matur�ment")
  # }
  dumtest <- lapply(lesenv, function(x) x$DoReflect)
  dumtest <- as.logical(dumtest)
  if (any(dumtest)){
    for (k in 1:N_instruments){
    graphics.off()
    par(op)
    #10 graphiques - 2 premiers pour le logo et 7 suivants pour la fluo, la derni�re pour r�flectance
    nf=layout(matrix(c(1,2,3),3,1,byrow=TRUE))
    #Affiche le logo
    par(mai=c(0,0,0,0))
    plot(as.raster(logo))
    
    par(mai=op$mai*0.35)
    
    
    with (lesenv[[k]],
          {
            if (DoReflect){
             readline(paste0("\nS'assurer que la lampe blanche pour ",
                                lesinstruments[[k]],
                                 " est en fonction \npuis appuyer sur Retour/Enter\n."))
              if (toupper(dum)=="Q"){
                Abort(lesDevices,lesspectros,OOobj,op)
                graphics.off()
                return("Quitt� pr�matur�ment")
              }
              #Ouvre le shutter
              readline(paste0("\nFermer l'obturateur de la source blanche pour ",
                                lesinstruments[[k]],
                              "\n", "Appuyer sur Retour/Enter.\n"))
              
              lespectro=Define_Acq_Param(OOobj,lespectro,T_Reflect,Box_Reflect,Scans_Reflect)
              Sys.sleep(0.2)
              
              
              #Mesure sur noir standard
              lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
              #Met le noir en r�serve
              noir_std=lespectro$sp
              Plot_Spectrum(lespectro,"brut")
              title(main="Noir standard")
              
              #Mesure sur standard de r�flectance
              readline(paste0("\nPlacer le standard de r�flectance  dans ",
                              lesinstruments[[k]], "\n",
                              "Ouvrir l'obturateur pour la source blanche puis appuyer sur Retour/Enter.\n"))
              lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
              blanc_std=lespectro$sp-noir_std
              lespectro$sp=blanc_std
              Plot_Spectrum(lespectro,"brut")
              title("R�f�rence blanche")
              
              #Ferme le shutter
              readline(paste0("\nFermer l'obturateur de la source blanche pour ",
                              lesinstruments[[k]], "\npuis appuyer sur Retour/Enter.\n"))
              
              
              #Permet de quitter le programme si c'est pas bon.
              dum="a"
              while (sum(toupper(dum)==c("O","N"))==0)
                dum=readline("\nSatisfait du profil de la lampe (O/N): ")
              if (toupper(dum)=="N"){ #quitter le programme.
                #Clean and close
                for (k in 1:lesDevices$nbdevices) ReleaseBoard(lesDevices$BoardNum[k])
                (Quitte_MCLIB())
                for (sp in lesspectros) Close_Spectro(sp)
                rm(OOobj)
                Quit_OO(OOobj)
                par(op)
                graphics.off()
                return("PolySPecteur a termin�! A la prochaine!")
              }
            }
          })
    }
  }
  
  
  
  
  
  #-----------------------------------------
  #_______________________________________________________
  # On d�marre la s�quence d'acquistion:
  
  #-----------------------------------------
  
  #On demande le fichier pour le plan d'exp�rience et on pr�pare la liste des �chantillons
  fichier_plan=rchoose.files(caption = "Choisir les fichier du plan d'exp�rience",
                             multi=FALSE,filters="*.txt")
  plan=read.table(fichier_plan,header=TRUE,sep="\t")
  nrow=dim(plan)[1]
  ncol=dim(plan)[2]
  liste_ech=c()
  for (k in 1:nrow){
    ligne=""
    for (i in 1:ncol){
      ligne=paste(ligne,as.character(plan[k,i]))
    }
    liste_ech=rbind(liste_ech,ligne)
  }
  
  
  
  #On demande le r�pertoire pour stocker les donn�es.
  #-----------------------------------------
  fichierDat_path=rchoose.dir("C:\\Users\\crdaspectral\\Documents\\Programmes\\SAIV_Version_Alain_2016\\Data",
                        "Choisir un r�pertoire pour les donn�es.")
  #Demande un identifiant pour cr�er le nom des fichiers de donn�es.
  identifiant=winDialogString("Entrer un identifiant pour les noms de fichier de donn�es",as.character(Sys.Date()))
  cat("\n")
  #-----------------------------------------
 
  
  #------------------- GESTION DE L'INTERFACE USAGER ---------------------------  
  selected=0
  DONE=FALSE   #On boucle le cycle d'acquisition tant que l'usager inscrit un 
               #un nouveau code d'�chantillon. Autrement, on arr�te. 
  
  for (k in 1:N_instruments){
    with(lesenv[[k]], {
      lesNoirs <- matrix(0,nrow=8,ncol=length(lespectro$xaxis))
      t0Noir <- Sys.time()-(Delai_noir*60)
    })
  }
  
  while (!DONE){   #Boucle principale sur les �chantillons
    
    #*****************************************************************************
    #Permet de changer de plan d'exp�rience
    newPlan=readline("\nNouveau plan d'exp�rience (O/N - D�faut=N): ") 
    if (toupper(newPlan)=='O'){
      #On demande le fichier pour le plan d'exp�rience et on pr�pare la liste des �chantillons
      fichier_plan=rchoose.files(caption = "Choisir les fichier du plan d'exp�rience",
                                 multi=FALSE,filters="*.txt")
      plan=read.table(fichier_plan,header=TRUE,sep="\t")
      nrow=dim(plan)[1]
      ncol=dim(plan)[2]
      liste_ech=c()
      for (k in 1:nrow){
        ligne=""
        for (i in 1:ncol){
          ligne=paste(ligne,as.character(plan[k,i]))
        }
        liste_ech=rbind(liste_ech,ligne)
      }
    }
    
    
    #*****************************************************************************
    #Choisir la prochaine mesure dans le plan d'exp�rience
    if (selected<nrow){
      ydata=select.list(liste_ech,title="Choisir le prochain �chantillon",preselect = liste_ech[selected+1],
                        graphics = TRUE)
    }else
    {
      ydata=select.list(liste_ech,title="Choisir le prochain �chantillon",preselect = liste_ech[selected],
                        graphics = TRUE)
    }
    if (ydata==""){
      DONE=TRUE
      dum=readline(prompt="\nRetirer le dernier �chantillon puis appuyer sur Enter.")
      cat("\n")
    }else
    {
    
      #*****************************************************************************
      #Choix de l'instrument
      instrument_actif <- 1
      if (N_instruments>1){
        dum=0
        while (dum<1 | dum>N_instruments){
          dumt=select.list(as.character(lesinstruments),multiple=F,title="Choisir les instruments",graphics=T)
          dum <- which(lesinstruments==dumt)
          instrument_actif=dum
        }
      }
      with (lesenv[[instrument_actif]],{
        if (DoFluo){
          dum <- get_DELs_dat("FEX",mon_envir = lesenv[[instrument_actif]])
          dum <- apply(dum,2,list)
          lesDels <- lapply(dum,function(x) as.list(unlist(x)))
         }
      })
      
      #*****************************************************************************  
      #Permettre la modification des param�tres
      newPlan='N'
      DoParam=readline("\n�diter les (P)aram�tres, (N)ouveau fihcier de param�tres ou (C)ontinuer (P/N/C - D�faut=C): ")
      if (toupper(DoParam)=='P'){
        edit(file=fichier_param[instrument_actif]) 
        source(fichier_param[instrument_actif],local=lesenv[[instrument_actif]])
      }else
      {if (toupper(DoParam)=='N')
        {
          fichier_param[instrument_actif]=rchoose.files(caption="Choisir le nouveau fichier des param�tres",multi = FALSE,filters = "*.R")
          source(fichier_param[instrument_actif],local=lesenv[[instrument_actif]])  #Charge les param�tres
        }
      }
    
      
   
    
      selected=which(ydata==liste_ech)
      EchID=plan[selected,1]
    
      
      
      with(lesenv[[instrument_actif]],{
        #///////////////////////////////////////////////////////////////
        #�crire le fichier des Y
        if (DoFluo | DoReflect){
          fichierDat=paste(fichierDat_path,"\\Y","_",identifiant,".txt",sep="")
          for (k in (1:Nb_reps_Fluo))
            writeY(selected,plan,lesinstruments[instrument_actif],k,fichierDat)
        }
        
        #///////////////////////////////////////////////////////////////
        if (DoFluo){    #### BOUCLE POUR LA FLUORESCENCE
          
          # D'abord, regroupe des param�tres dans des listes/vecteurs
          Fluo_EX <- get_DELs_dat("DoEX", mon_envir = lesenv[[instrument_actif]])
          T_Fluo <- get_DELs_dat("T_EX", mon_envir = lesenv[[instrument_actif]])
          Box_FLuo <- get_DELs_dat("Box_EX", mon_envir = lesenv[[instrument_actif]])
          Scans_Fluo <- get_DELs_dat("Scans_EX", mon_envir = lesenv[[instrument_actif]])
          lesEXs <- get_DELs_dat("EX", mon_envir = lesenv[[instrument_actif]])
          FluoDel_I <- get_DELs_dat("LED_I_EX", mon_envir = lesenv[[instrument_actif]])
          
          
          lespectro=Define_WavelengthRange(lespectro,fluo_l_min,fluo_l_max,fluo_step)
          Sys.sleep(0.2)
         
          for (krep in 1:Nb_reps_Fluo){
            readline(paste("\nPlacer l'�chantillon ",EchID,
                           " � la position ",as.character(krep),
                           " dans l'instrument ", lesinstruments[instrument_actif],
                           sep=""))
            #Remise � z�ro de la fen�tre graphique
            graphics.off()
            par(op)
            #10 graphiques - 2 premiers pour le logo et 7 suivants pour la fluo, la derni�re pour r�flectance
            nf=layout(matrix(c(1,1,2,3,4,5,6,7,8,9),5,2,byrow=TRUE))
            #Affiche le logo
            par(mai=c(0,0,0,0))
            plot(as.raster(logo))
            
            par(mai=op$mai*0.35)
            
            #D�finir un "flag" pour savoir s'il faut refaire les noirs
            tnow_noir=as.numeric(Sys.time())
            dt=(tnow_noir-as.numeric(t0Noir))/60
            flag_noir=FALSE
            if (dt>Delai_noir){
              cat("D�lai pour noir: ",dt,"\n")
              flag_noir = TRUE
              t0Noir=as.numeric(Sys.time())
            }
            
            for (k in RangFluo){
              if (Fluo_EX[k]){
                #Prep du spectro
                lespectro=Define_Acq_Param(OOobj,lespectro,T_Fluo[k],Box_FLuo[k],Scans_Fluo[k])
                Sys.sleep(0.2)
                
                #Prendre un spectre au noir
                if (flag_noir){
                  cat("Acquisition d'un noir.\n")
                  lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
                  #Met le noir en r�serve
                  lesNoirs[k,]=lespectro$sp
                }
             
                #Allume la DEL � EXi_DEL_I milliamp�res
                I_OUT(lesDels[[k]],lesDevices,FluoDel_I[k])
                Sys.sleep(T_DEL)       #Attend T_DEL secondes pour stabiliser la DEL
                
                #Prendre un spectre brut de fluo � 280 nm
                
                cat(paste("Acquisition de fluorescence � ",as.character(lesEXs[k])," nm.\n",sep=""))
                lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
                
                #Coupe l'alimentation de la DEL (0 milliamps)
                I_OUT(lesDels[[k]],lesDevices,0)
                
                #Soustraire le noir
                lespectro$sp=lespectro$sp-lesNoirs[k,]
                
                #On stocke les donn�es brutes
                fichierDat=paste(fichierDat_path,"\\EX",as.character(lesEXs[k]),"_",identifiant,"_B.txt",sep="")
                writeDAT_Fluo(lespectro$xaxis,lespectro$sp,fichierDat,EchID)
                
                
                #Applique la correction
                lespectro$sp=gainY*lespectro$sp
                #Normalise pour le pic d'�talonnage du d�but de la session
                lespectro$sp=lespectro$sp/NormY[k]
                
                
                #On fait l'interpolation
                lespectro=Interpolate_Spectrum(lespectro)
                lespectro$int$y=lespectro$int$y/T_Fluo[k]*1000   #Normalise par le temps d'exposition en secondes
                
                # On montre le spectre interpol� 
                x0=lesEXs[k]+25
                xend=range(lespectro$int$x)[2]
                i1=which(lespectro$int$x>=x0)[1]
                i2=length(lespectro$int$x)
                Plot_Spectrum(lespectro,"interpole",xlim=c(x0,xend),ylim=range(lespectro$int$y[i1:i2]))
                title(paste("�chantillon ",EchID," � ", as.character(lesEXs[k])," - Rep = ",as.character(krep), sep=""))
                grid()
               
                #On stocke les donnees interpolees
                fichierDat=paste(fichierDat_path,"\\EX",as.character(lesEXs[k]),"_",identifiant,"_I.txt",sep="")
                writeDAT_Fluo(lespectro$int$x,lespectro$int$y,fichierDat,EchID)
              }else
              {
                plot(c(0,1),c(0,1), type="n", axes=F, xlab="", ylab="")    #Pour passer au graphique suivant
                text(0.5,0.5,paste("Pas de fluo. � ",as.character(lesEXs[k]), sep=""))
              }
            }
            
          }#boucle des reps
          ###Fin de la boucle pour la fluo
        }else
          if (!partout){
            for (krep in 1:Nb_reps_Fluo){
              for (k in RangFluo){
                if (Fluo_EX[k]){
                  #On stocke les donn�es bidons en format de donn�es brutes
                  fichierDat=paste(fichierDat_path,"\\EX",as.character(lesEXs[k]),"_",identifiant,"_B.txt",sep="")
                  #Trouve un spectro qui fait la fluorescence
                  lekk=0
                  for (kk in 1:N_instruments){
                    if (lesenv[[kk]]$DoFluo){
                      lekk=kk
                    }
                    if (lekk>0) break
                  }
                  
                  ydum=rep(NA,length(lesenv[[lekk]]$lespectro$xaxis))
                  writeDAT_Fluo(lesenv[[lekk]]$lespectro$xaxis,ydum,fichierDat,EchID)
                  
                  #On stocke les donnees bidons en format de donn�es interpol�es
                  fichierDat=paste(fichierDat_path,"\\EX",as.character(lesEXs[k]),"_",identifiant,"_I.txt",sep="")
                  xdum <- seq(lesenv[[lekk]]$fluo_l_min,lesenv[[lekk]]$fluo_l_max,lesenv[[lekk]]$fluo_step)
                  ydum=rep(NA,length(xdum))
                  writeDAT_Fluo(xdum,ydum,fichierDat,EchID)
                }
              }
            }
          }###Fin de la boucle pour la fluo
        
        
        
        #///////////////////////////////////////////////////////////////
        if (DoReflect){    #### BOUCLE POUR LA R�FLECTANCE
          lespectro=Define_WavelengthRange(lespectro,reflect_l_min,reflect_l_max,reflect_step)
          Sys.sleep(0.2)
          
          lespectro=Define_Acq_Param(OOobj,lespectro,T_Reflect,Box_Reflect,Scans_Reflect)
          Sys.sleep(0.2)
          
          #Remise � z�ro de la fen�tre graphique
          graphics.off()
          par(op)
          #10 graphiques - 2 premiers pour le logo. 
          #3 pour noir de r�f�rence, 4 pour le blanc de r�f�rence, 5 � 10 pour les
          #reps (pas plus de 6!)
          nf=layout(matrix(c(1,1,2,3,4,5,6,7,8,9),5,2,byrow=TRUE))
          #Affiche le logo
          par(mai=c(0,0,0,0))
          plot(as.raster(logo))
          
          par(mai=op$mai*0.35)
          
          
          #Ouvre le shutter
          readline(paste("\nS'assurer que l'obturateur de la source blanche pour l'instrument ",
                          lesinstruments[instrument_actif], " est ferm�. \n",
                         "Puis appuyer sur Retour/Enter.",
                         sep=""))
          
          #Mesure sur noir standard
          lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
          Plot_Spectrum(lespectro,"brut")
          title(main="Noir standard")
          #Met le noir en r�serve
          noir_std=lespectro$sp
          
          #Mesure sur standard de r�flectance
          readline(paste("\nPlacer le standard de r�flectance  dans l'instrument ",
                          lesinstruments[instrument_actif], "\n",
                         "Ouvrir l'obturateur de la source blanche de l'instrument ",
                          lesinstruments[instrument_actif], "\n",
                          "Appuyer sur Retour/Enter.",sep=""))
          lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
          blanc_std=lespectro$sp-noir_std
          # Correction pour le stray light
          if (stray_low>0){
            i1 <- which(lespectro$xaxis>=stray_low)[1]
            i2 <- which(lespectro$xaxis>=stray_high)[1]
            stray <- mean(blanc_std[i1:i2])
            blanc_std <- blanc_std-stray
          }
          lespectro$sp=blanc_std
          Plot_Spectrum(lespectro,"brut")
          
          
          for (krep in 1:Nb_reps_Reflect){
            readline(paste("\nPlacer l'�chantillon ",EchID,
                           " � la position ",as.character(krep),
                           "dans l'instrument ", lesinstruments[instrument_actif],
                           sep=""))
           
            #Lire le spectre brut
            lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
            data_ech <- lespectro$sp-noir_std
            
            # Correction pour le stray light
            if (stray_low>0){
              i1 <- which(lespectro$xaxis>=stray_low)[1]
              i2 <- which(lespectro$xaxis>=stray_high)[1]
              stray <- mean(data_ech[i1:i2])
              data_ech <- data_ech-stray
            }
            
            #Calcul de r�flectance
            lespectro$sp=data_ech/blanc_std
            
            #On fait l'interpolation
            lespectro=Interpolate_Spectrum(lespectro)
            
            # On montre le spectre interpol� 
            Plot_Spectrum(lespectro,"interpole",xlim=c(250,800),ylim=c(0,1.2))
            title(paste("�chantillon ",EchID," - Rep = ",as.character(krep), sep=""))
            grid()
            
            #On stocke les donnees interpolees
            fichierDat=paste(fichierDat_path,"\\Transmit","_",identifiant,"_I.txt",sep="")
            writeDAT_Transmit(lespectro$int$x,lespectro$int$y,fichierDat,EchID)
          }
          #Ouvre le shutter
          readline(paste("\nFemer l'obturateur de la source blanche pour l'instrument ",
                          lesinstruments[instrument_actif], "\n",
                         "Puis appuyer sur Retour/Enter.",
                         sep=""))
        }else
          if (!partout){
            for (krep in 1:Nb_reps_Reflect){
              #On stocke les donnees bidons en format de donn�es interpolees
              fichierDat=paste(fichierDat_path,"\\Transmit","_",identifiant,"_I.txt",sep="")
              #Trouve un spectro qui fait la transmittance
              lekk=0
              for (kk in 1:N_instruments){
                if (lesenv[[kk]]$DoReflect){
                  lekk=kk
                }
                if (lekk>0) break
              }
              xdum <- seq(lesenv[[lekk]]$reflect_l_min,lesenv[[lekk]]$reflect_l_max,lesenv[[lekk]]$reflect_step)
              ydum <- rep(NA,length(xdum))
              writeDAT_Transmit(xdum,ydum,fichierDat,EchID)
            }
          }
        ### Fin de la boucle de r�flectance
        
        #///////////////////////////////////////////////////////////////
        dum=readline(prompt=paste("\nRetirer l'�chantillon ", EchID,
                                  " de l'instrument ", lesinstruments[instrument_actif],
                                   " puis appuyer sur Enter.",sep=""))
        cat("\n")
        cat("\n")
      })
    }
  }
  
  #///////////////////////////////////////////////////////////////
  #Clean and close
  for (k in 1:lesDevices$nbdevices) ReleaseBoard(lesDevices$BoardNum[k])
  (Quitte_MCLIB())
  for (sp in lesspectros) Close_Spectro(sp)
  rm(OOobj)
  Quit_OO(OOobj)
  cat("\nPolySPecteur a termin�! A la prochaine!\n")
  par(op)
  graphics.off()
}

#writeY
#-----------------------------------------
#Fonction pour �crire le fichier des Y
writeY<-function(selected,plan,instrum,rep,monfichier)
  #�crire les donn�es ds un fichier en format txt avec "tab" comme s�parateur
{ 
  ladate=as.character(Sys.Date())
  letemps=format(Sys.time(),"%X")
  ligne=NULL
  ncol=dim(plan)[2]
  for (i in 1:ncol){
    ligne=c(ligne,as.character(plan[selected,i]))
  }
  ligne=c(ligne,ladate,letemps,instrum,rep)
  #On proc�de
  if (file.exists(monfichier)==TRUE){  #seulement les identifiants
    mycon=file(monfichier,"a")
    cat(ligne,file=mycon,sep="\t")
    cat("\n",file=mycon)
    close(mycon)
  }
  else{
    entete=c(names(plan),"Date","Heure","Instrument","PosRep")
    mycon=file(monfichier,"a")   #Ent�te puis les identifiants
    cat(entete,file=mycon,sep="\t")   #ent�te
    cat("\n",file=mycon)
    cat(ligne,file=mycon,sep="\t") #donn�es
    cat("\n",file=mycon)
    close(mycon)
  }
  invisible(0)
}

#-----------------------------------------

#writeDAT_Fluo
#-----------------------------------------
#Fontion qui �crit les donn�es de fluorescence dans un fichier.
writeDAT_Fluo<-function(wl,sp,monfichier,echID)
  #�crire les donn�es ds un fichier en format txt avec "tab" comme s�parateur
{ 
  #On proc�de
    if (file.exists(monfichier)==TRUE){  #seulement le spectre
      mycon=file(monfichier,"a")
      cat(paste(echID,"\t",sep=""),file=mycon)
      cat(sp,file=mycon,sep="\t")
      cat("\n",file=mycon)
      close(mycon)
    }
    else{
      mycon=file(monfichier,"a")   #nombres d'onde puis le spectre
      cat("\t",file=mycon)
      cat(wl,file=mycon,sep="\t")   #ent�te
      cat("\n",file=mycon)
      cat(paste(echID,"\t",sep=""),file=mycon)  #Id. d'�chantillon
      cat(sp,file=mycon,sep="\t") #donn�es
      cat("\n",file=mycon)
      close(mycon)
    }
  invisible(0)
}

#-----------------------------------------

#writeDAT_Transmit
#-----------------------------------------
#Fontion qui �crit les donn�es de tansmittance dans un fichier.
writeDAT_Transmit<-function(wl,sp,monfichier,echID)
  #�crire les donn�es ds un fichier en format txt avec "tab" comme s�parateur
{ 
  #On proc�de
  if (file.exists(monfichier)==TRUE){  #seulement le spectre
    mycon=file(monfichier,"a")
    cat(paste(echID,"\t",sep=""),file=mycon)
    cat(sp,file=mycon,sep="\t")
    cat("\n",file=mycon)
    close(mycon)
  }
  else{
    mycon=file(monfichier,"a")   #nombres d'onde puis le spectre
    cat("\t",file=mycon)
    cat(wl,file=mycon,sep="\t")   #ent�te
    cat("\n",file=mycon)
    cat(paste(echID,"\t",sep=""),file=mycon)  #Id. d'�chantillon
    cat(sp,file=mycon,sep="\t") #donn�es
    cat("\n",file=mycon)
    close(mycon)
  }
  invisible(0)
}

#-----------------------------------------

#Mesures_Etalon_Fluo
#-----------------------------------------
Mesures_Etalon_Fluo <- function(instrument.env,lespectro,OOobj,lesDevices,gainMaya,logo,op,lesEXs){
  
  dum <- get_DELs_dat("FEX",mon_envir = instrument.env)
  dum <- apply(dum,2,list)
  lesDels <- lapply(dum,function(x) as.list(unlist(x)))
  
  lespectro=Define_WavelengthRange(lespectro,instrument.env$fluo_l_min,
                              instrument.env$fluo_l_max,
                              instrument.env$fluo_step)
  Sys.sleep(0.2)
  
  N_ExFluo <- length(lesDels)
  NormY <- rep(0,N_ExFluo)
  
  #R�cup�re l'assignation � un standard pour chaque DEL
  std_4_DEL <- get_DELs_dat("STD_EX",mon_envir = instrument.env)
  #Liste des standards
  les_stds <- unique(std_4_DEL)
  #Nombre de standards
  N_std <- length(les_stds)
  
  #V�rifie si le fichier Instrument_x_Verif.txt existe. Non, on le cr�e.
  #Oui, on lit les donn�es.
  #path='Fichiers_Instruments'
  lefichier=instrument.env$Instrument_Verif_File
  if (file.exists(lefichier)){
    histoire = read.table(lefichier,header=TRUE,sep="\t",stringsAsFactors = FALSE)
    histoire_length=nrow(histoire)
  }else
  {
    histoire=data.frame('Date'=as.character(),'Heure'=as.character(),stringsAsFactors = FALSE)
    for (kk in 1:N_ExFluo) histoire <- eval(parse(text=paste0("cbind(histoire,'DEL",kk,"'=as.numeric())")))
    
    histoire_length=nrow(histoire)
  }
  if (histoire_length>0){
    mean_DEL_I=colMeans(histoire[,-c(1,2)])
  }else
  {
    mean_DEL_I <- rep(0,N_ExFluo)
  }
  
  #Remise � z�ro de la fen�tre graphique
  graphics.off()
  par(op)
  #10 graphiques - premier pour le logo et 8 suivants pour la fluo
  nf=layout(matrix(c(1,2,3,4,5,6,7,8,9,10),5,2,byrow=TRUE))
  #Affiche le logo
  par(mai=c(0,0,0,0))
  plot(as.raster(logo))
  par(mai=op$mai*0.35)
  
  maxi=matrix(0,ncol=N_ExFluo,nrow=instrument.env$Instr_reps)
  les_ii=matrix(0,ncol=N_ExFluo,nrow=instrument.env$Instr_reps)
  for (ijk in (1:N_std)){
    readline(paste0("\nPlacer l'�talon ",les_stds[ijk], " dans l'instrument."))
    lesk <- which(std_4_DEL==les_stds[ijk])
    for (jj in 1:instrument.env$Instr_reps){
      if (jj>1) readline("\nD�placer l'�talon, puis ENTER.")
      for (k in lesk){
        lespectro=Define_Acq_Param(OOobj,lespectro,instrument.env$Instr_T_exp_test[[std_4_DEL[k]]][k],
                              instrument.env$Instr_Boxcar_test[[std_4_DEL[k]]][k],
                              instrument.env$Instr_N_scans_test[[std_4_DEL[k]]][k])
        Sys.sleep(0.2)
        cat(paste("Acquisition d'un noir pour la DEL ",as.character(k),".\n",sep=""))
        lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
        #Met le noir en r�serve
        noir=lespectro$sp
        #Allume la DEL � EXi_DEL_I milliamp�res
        I_OUT(lesDels[[k]],lesDevices,instrument.env$FluoDel_I_test[[std_4_DEL[k]]][k])
        Sys.sleep(instrument.env$T_DEL)       #Attend T_DEL secondes pour stabiliser la DEL
        cat(paste("Acquisition de fluorescence pour la DEL ",as.character(k),".\n",sep=""))
        lespectro=Grab_Spectrum(lespectro,OOobj$mywrap)
        #Coupe l'alimentation de la DEL (0 milliamps)
        I_OUT(lesDels[[k]],lesDevices,0)
        #Soustraire le noir
        lespectro$sp=lespectro$sp-noir
        lespectro$sp=gainMaya*lespectro$sp
        #Divise par le temps d'exposition sec, 1000 parce que le temps est en msec
        lespectro$sp=lespectro$sp/instrument.env$Instr_T_exp_test[[std_4_DEL[k]]][k]*1000
        #On fait l'interpolation
        lespectro=Interpolate_Spectrum(lespectro)
        #Trouve max
        i1=floor(instrument.env$Norm_Y_peak[[std_4_DEL[k]]]-instrument.env$Norm_Y_BW[[std_4_DEL[k]]]/2)
        i1=which(lespectro$int$x>=i1)[1]
        i2=ceiling(instrument.env$Norm_Y_peak[[std_4_DEL[k]]]+instrument.env$Norm_Y_BW[[std_4_DEL[k]]]/2)
        i2=which(lespectro$int$x>i2)[1]-1
        ii=i1-1+which.max(lespectro$int$y[i1:i2])
        les_ii[jj,k]=ii
        #Moyenne sur �2 pixels
        #maxi[jj,k]=mean(lespectro$int$y[(ii-2):(ii+2)]) 
        #savgol puis maximum
        dum=savitzkyGolay(lespectro$int$y[(ii-5):(ii+5)],0,3,5)
        maxi[jj,k]=dum[4]
      }
    }
  }
  for (k in 1:N_ExFluo){
    NormY=colMeans(maxi)
    iis=colMeans(les_ii)
    i2=histoire_length
    if (i2>5){
      i1=i2-4
    }else
    {
      i1=1
    }
    if (histoire_length==0){
      dat_4_plot=c(mean_DEL_I[k],NormY[k])
      names_4_plot=c("Moyenne","Courant")
      barplot(dat_4_plot,names.arg=names_4_plot,main=paste("Excitation � ",
              as.character(lesEXs[k])," nm - Absolu",sep=""))
    }else
    {
      dat_4_plot=c(mean_DEL_I[k],histoire[(i1:i2),(k+2)],NormY[k])
      dat_4_plot=dat_4_plot/dat_4_plot[1]
      names_4_plot=c("Moyenne",histoire[(i1:i2),1],"Courant")
      barplot(dat_4_plot,names.arg=names_4_plot,main=paste("Excitation � ",
             as.character(lesEXs[k])," nm - Rel. � moyenne",sep=""))
    }
  }

  larow=nrow(histoire)+1
  histoire[larow,1] <-  format(Sys.time(),"%D")
  histoire[larow,2] <- format(Sys.time(),"%H:%M:%S")
  for (kk in 1:N_ExFluo){
    histoire[larow,kk+2] <- NormY[kk]
  }
  write.table(histoire,lefichier,sep="\t")
  return(NormY)
}

#-----------------------------------------

#Abort <- function(lesDevices,lesspectros,OOobj,op)
#-----------------------------------------
Abort <- function(lesDevices,lesspectros,OOobj,op){
  for (k in 1:lesDevices$nbdevices) ReleaseBoard(lesDevices$BoardNum[k])
  (Quitte_MCLIB())
  for (sp in lesspectros) Close_Spectro(sp)
  rm(OOobj)
  Quit_OO(OOobj)
  cat("\nPolySPecteur a termin�! A la prochaine!\n")
  par(op)
  return()
}

#-----------------------------------------
get_DELs_dat <- function(varname,mon_envir=.GlobalEnv)
  #Fonction pour r�cup�rer des vecteurs/listes de param�tres
{
  dum <- ls(envir = mon_envir, pattern = paste0("^",varname,".$"))
  dum <- unname(sapply(dum,FUN=function(x) get(x,envir=mon_envir)))
  return(dum)
}
#-----------------------------------------


